import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { startWith, debounceTime, distinctUntilChanged, switchMap, map } from 'rxjs/operators';
import { FormControl } from '@angular/forms';
import { PostService } from '../post.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss']
})
export class UserComponent implements OnInit {
  myControl = new FormControl();
  options: any = [];
  filteredOptions: Observable<any>;

  constructor(private service: PostService) {
    this.filteredOptions = this.myControl.valueChanges.pipe(
      startWith(''),
      switchMap(val => {
        return this.filter(val || '')
      })
    )
  }

  filter(val: string): Observable<any> {

    return this.service.getData()
      .pipe(
        map(response => response.filter((option: any) => {
          return option.name.toLowerCase().indexOf(val.toLowerCase()) === 0
        }))
      )
  }

  ngOnInit(): void {
  }

}
