import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';
import { of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PostService {

  constructor(private http: HttpClient) { }

  opts: any = [];

  getData() {
    return this.opts.length ? 
    of(this.opts) : 
    this.http.get('./assets/state.json').pipe(tap(data => this.opts = data))
  }
}
